# Eiendomsavkastningskalkulator

En enkel Flask-applikasjon for beregning av eiendomsavkastning.
